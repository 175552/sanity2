package assignment;
import java.awt.*;
import java.util.*;
/*
 *
 * CS314H Programming Assignment 1 - Java image processing
 *
 * Included is the Invert effect from the assignment.  Use this as an
 * example when writing the rest of your transformations.  For
 * convenience, you should place all of your transformations in this file.
 *
 * You can compile everything that is needed with
 * javac -d bin src/assignment/*.java
 *
 * You can run the program with
 * java -cp bin assignment.JIP
 *
 * Please note that the above commands assume that you are in the prog1
 * directory.
 */

class Invert extends ImageEffect {
    public int[][] apply(int[][] pixels,
                         ArrayList<ImageEffectParam> params) {
        int width = pixels[0].length;
        int height = pixels.length;

        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                pixels[y][x] = ~pixels[y][x];
            }
        }
        return pixels;
    }
}

class Dummy extends ImageEffect {

    public Dummy() {
        params = new ArrayList<>();
        params.add(new ImageEffectParam("ParamName",
                "Description of param.",
                10, 0, 1000));
    }

    public int[][] apply(int[][] pixels,
                         ArrayList<ImageEffectParam> params) {
        // Use params here.
        return pixels;
    }
}

//no_____ sets respective rgb value to 0
class NoRed extends ImageEffect{
    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params) {
        int width = pixels[0].length;
        int height = pixels.length;

        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                pixels[y][x] = makePixel(0, getGreen(pixels[y][x]), getBlue(pixels[y][x]));
            }
        }
        return pixels;
    }
}
class NoGreen extends ImageEffect {
    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params) {
        int width = pixels[0].length;
        int height = pixels.length;

        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                pixels[y][x] = makePixel(getRed(pixels[y][x]), 0, getBlue(pixels[y][x]));
            }
        }
        return pixels;
    }
}
class NoBlue extends ImageEffect {
    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params) {
        int width = pixels[0].length;
        int height = pixels.length;
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                pixels[y][x] = makePixel(getRed(pixels[y][x]), getGreen(pixels[y][x]), 0);
            }
        }
        return pixels;
    }
}
//_____only sets all other rgb values to 0
class RedOnly extends ImageEffect {
    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params) {
        int width = pixels[0].length;
        int height = pixels.length;

        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                pixels[y][x] = makePixel(getRed(pixels[y][x]), 0, 0);
            }
        }
        return pixels;
    }
}
class BlueOnly extends ImageEffect {
    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params) {
        int width = pixels[0].length;
        int height = pixels.length;

        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                pixels[y][x] = makePixel(0, 0, getBlue(pixels[y][x]));
            }
        }
        return pixels;
    }
}
class GreenOnly extends ImageEffect {
    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params) {
        int width = pixels[0].length;
        int height = pixels.length;

        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                pixels[y][x] = makePixel(0, getGreen(pixels[y][x]), 0);
            }
        }
        return pixels;
    }
}
//implements grayscale utilizing the idea that when all rgb values are equivalent the result is the color grey
class BLackAndWhite extends ImageEffect {
    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params) {
        int width = pixels[0].length;
        int height = pixels.length;

        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                int average = (getRed(pixels[y][x]) + getBlue(pixels[y][x]) + getGreen(pixels[y][x]))/3;
                pixels[y][x] = makePixel(average, average, average);
            }
        }
        return pixels;
    }
}
class VerticalReflect extends ImageEffect{
    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params) {
        int width = pixels[0].length;
        int height = pixels.length;
        int[][] temp = new int[height][width]; //flipped array
        for(int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                temp[y][x] = pixels[y][x];
            }
        }
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                pixels[y][x] = temp[y][width - x - 1]; //vertically reflects each pixel
            }
        }
        return pixels;
    }
}
class HorizontalReflect extends ImageEffect{
    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params) {
        int width = pixels[0].length;
        int height = pixels.length;
        int[][] temp = new int[height][width]; //flipped array
        for(int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                temp[y][x] = pixels[y][x];
            }
        }
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                pixels[y][x] = temp[height - y - 1][x]; //horizontally reflects each pixel
            }
        }
        return pixels;
    }
}
//doubles the width + height, essentially turning 1 pixel into 4
class Grow extends ImageEffect{
    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params) {
        int width = pixels[0].length;
        int height = pixels.length;
        int[][] temp = new int[height * 2][width * 2]; //grown image
        for(int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                int cur = pixels[y][x];
                temp[y * 2][x * 2] = cur;
                temp[y * 2 + 1][x * 2] = cur;
                temp[y * 2][x * 2 + 1] = cur;
                temp[y * 2 + 1][x * 2 + 1] = cur;
            }
        }
        return temp;
    }
}

//halves the width and height by converting 4 pixels in the original image to 1
class Shrink extends ImageEffect{
    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params) {
        int width = pixels[0].length;
        int height = pixels.length;
        int[][] temp = new int[height / 2][width / 2];
        for(int x = 0; x < width/2; x++) {
            for (int y = 0; y < height/2; y++) {
                //averages the rgb values from 4 pixels in the original image
                temp[y][x] = makePixel((getRed(pixels[2 * y][2 * x]) + getRed(pixels[2 * y + 1][2 * x]) + getRed(pixels[2 * y][2 * x + 1]) + getRed(pixels[2 * y + 1][2 * x + 1]))/4, (getGreen(pixels[2 * y][2 * x]) + getGreen(pixels[2 * y + 1][2 * x]) + getGreen(pixels[2 * y][2 * x + 1]) + getGreen(pixels[2 * y + 1][2 * x + 1]))/4, (getBlue(pixels[2 * y][2 * x]) + getBlue(pixels[2 * y + 1][2 * x]) + getBlue(pixels[2 * y][2 * x + 1]) + getBlue(pixels[2 * y + 1][2 * x + 1]))/4);
            }
        }
        return temp;
    }
}
class Threshold extends ImageEffect{
    public Threshold() {
        params = new ArrayList<>();
        params.add(new ImageEffectParam("Threshold",
                "Sharpens image based on threshold value",
                255/2, 0, 255));
    }
    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params) {
        int width = pixels[0].length;
        int height = pixels.length;
        int value = params.get(0).getValue();
        for(int x = 0; x < width; x++) {
            for(int y = 0; y < height; y++) {
                //maxes or mins each rbg value based on threshold
                pixels[y][x] = makePixel((getRed(pixels[y][x]) > value) ? 255 : 0, (getGreen(pixels[y][x]) > value) ? 255 : 0, (getBlue(pixels[y][x]) > value) ? 255 : 0);
            }
        }
        return pixels;
    }
}
class Smooth extends ImageEffect{
    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params) {
        int width = pixels[0].length;
        int height = pixels.length;
        for(int x = 0; x < width; x++) {
            for(int y = 0; y < height; y++) {
                int red = 0;
                int green = 0;
                int blue = 0;
                //8 possible pixel directions
                int[] dy = {1, 1, 1, 0, 0, -1, -1, -1};
                int[] dx = {1, 0, -1, 1, -1, 1, 0, -1};
                int total = 8;
                for(int i = 0; i < 8; i++) {
                    //try catch for edge pixels that don't have 8 pixels around them
                    try{
                        //sum of each rbg value of neighboring pixels
                        red += getRed(pixels[y + dy[i]][x + dx[i]]);
                        blue += getBlue(pixels[y + dy[i]][x + dx[i]]);
                        green += getGreen(pixels[y + dy[i]][x + dx[i]]);
                    } catch(Exception e) {
                        total--;
                    }
                }
                red /= total;
                green /= total;
                blue /= total;
                pixels[y][x] = makePixel(red, green ,blue);
            }
        }
        return pixels;
    }
}

/*
    turns current image into a puzzle based on an inputted number of pieces idk how else to explain.
    note that puzzles do not "stack" e.g. if you call the puzzle effect more than once,
    with the values being relatively prime the resulting puzzle is a puzzle based on the first
    puzzle and looks really funky
 */
class Puzzle extends ImageEffect{
    public Puzzle() {
        params = new ArrayList<>();
        //number of puzzle pieces per side e.g. total pieces is value squared
        params.add(new ImageEffectParam("Puzzle",
                "Turns image into a mixed puzzle of pieces of the original image",
                1, 1, (int)Math.sqrt(Integer.MAX_VALUE)));
    }
    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params) {
        int width = pixels[0].length;
        int height = pixels.length;
        int value = params.get(0).getValue();
        //adjusts number of pieces if it's greater than pixels per side
        if(value > Math.min(width, height)) {
            value = Math.min(width, height);
        }
        int newWidth = width;
        int newHeight = height;
        //adjusts width if the number of pixels doesn't divide evenly by finding the closest multiple
        if(width % value != 0) {
            newWidth = (width/value) * value + value;
        }
        //adjusts height if the number of pixels doesn't divide evenly by finding the closest multiple
        if(height % value != 0) {
            newHeight = (height/value) * value + value;
        }
        int[][] temp = new int[newHeight][newWidth];
        int[][] newPixels = new int[newHeight][newWidth];
        //initializes new image to be all white
        //useful because if the image did not divide evenly, it acts as white border on the outside of the image
        for(int x = 0; x < newWidth; x++) {
            for(int y = 0; y < newHeight; y++) {
                newPixels[y][x] = makePixel(255, 255, 255);
            }
        }
        //variables that store the current pixel of the original image
        int prex = 0;
        int prey = 0;
        //translates pixels from original image to new image
        //taking into account if the image was enlargened, then the original image is centralized
        //x,y are the new image position, accounting for if the "white border" was added
        for(int x = 0; x < width; x++, prex++){
            for(int y = 0; y < height; y++, prey++){
                newPixels[y][x] = pixels[prey][prex];
            }
            prey = 0;
        }
        //stores the top left coordinate of each "puzzle piece"
        ArrayList<Point> pieces = new ArrayList<>();
        //adds pieces to the list
        for(int x = 0; x < newWidth; x += newWidth/value) {
            for(int y = 0; y < newHeight; y += newHeight/value) {
                pieces.add(new Point(y, x));
            }
        }
        Random r = new Random();
        //loops through every top left coordinate
        for(int x = 0; x < newWidth; x += newWidth/value) {
            for(int y = 0; y < newHeight; y += newHeight/value) {
                //gets random piece from list
                int cur = r.nextInt(pieces.size());
                Point p = pieces.get(cur);
                //adds piece to new image
                for(int w = 0; w < newWidth/value; w++) {
                    for(int e = 0; e < newHeight/value; e++) {
                        temp[y + e][x + w] = newPixels[p.x + e][p.y + w];
                    }
                }
                //removes piece from list so random works as correctly
                pieces.remove(cur);
            }
        }
        return temp;
    }
}
//swap pieces of the puzzle so that you can solve it if you want to!
/*
Intended to be called after puzzle, also cannot determine if user inputs different piece value
without modifying starter code.
 */
class Swap extends ImageEffect{
    int pieces;
    public Swap(){
        params = new ArrayList<>();
        //gets the number of pieces the puzzle is formed from and two pieces to swap
        //where it counts starting from top left, then horizontally, then vertically
        //e.g.
        //1 2
        //3 4
        params.add(new ImageEffectParam("Pieces", "The same number you inputted for the puzzle effect (please or it will look very wonky)\nIf you don't call puzzle before swap, it will just treat the original image as the puzzle\n and this would be the number of pieces in said puzzle", 1, 1, Integer.MAX_VALUE));
        params.add(new ImageEffectParam("Swap",
                "First puzzle piece (where pieces are counted starting from 1 being the top left then counting horizontally first then vertically)",
                1, 1, Integer.MAX_VALUE));
        params.add(new ImageEffectParam("Swap", "Second puzzle piece (where pieces are counted starting from 1 being the top left then counting horizontally first then vertically)",
                1, 1, Integer.MAX_VALUE));
    }
    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params) {
        int width = pixels[0].length;
        int height = pixels.length;
        pieces = params.get(0).getValue();
        //ensure code won't break if user inputs super high number
        if(pieces > width || pieces > height) {
            pieces = Math.min(width, height);
        }
        int p1 = params.get(1).getValue();
        int p2 = params.get(2).getValue();
        //you must select a valid piece between 1 and pieces squared
        if(p1 > pieces * pieces || p2 > pieces * pieces) {
            System.out.println("Invalid piece, total number of pieces = " + (pieces * pieces));
            return pixels;
        }
        int cur = 1;
        Point s1 = new Point();
        Point s2 = new Point();
        //finds the coordinates of the top left corner of each piece based on indicated piece number
        for(int y = 0; y < height; y += height/pieces) {
            for(int x = 0; x < width; x += width/pieces) {
                if(cur == p1) {
                    s1 = new Point(y, x);
                }
                if(cur == p2) {
                    s2 = new Point(y, x);
                }
                cur++;
            }
        }
        //intializes newPixels to max value which will be used later
        //could be initialized to anything though
        int[][] newPixels = new int[height][width];
        for(int i = 0; i < height; i++) {
            Arrays.fill(newPixels[i], Integer.MAX_VALUE);
        }
        //first "swap"
        //sets first piece to the place of the second piece
        for(int x = 0; x < width/pieces; x++) {
            for(int y = 0; y < height/pieces; y++) {
                newPixels[s2.x + y][s2.y + x] = pixels[s1.x + y][s1.y + x];
            }
        }
        //second "swap"
        //sets second piece to the place of the first piece
        for(int x = 0; x < width/pieces; x++) {
            for(int y = 0; y < height/pieces; y++) {
                newPixels[s1.x + y][s1.y + x] = pixels[s2.x + y][s2.y + x];
            }
        }
        //adds remaining pixels from original array
        //utilizes initialization of array to only add pixels that were not swapped
        for(int x = 0; x < width; x++) {
            for(int y = 0; y < height; y++) {
                if(newPixels[y][x] == Integer.MAX_VALUE) {
                    newPixels[y][x] = pixels[y][x];
                }
            }
        }
        return newPixels;
    }
}








